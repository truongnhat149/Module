package com.example.gamepikachu;

//enum này là các hằng số chỉ các hướng di chuyển
// None là trong lần di chuyển đầu tiên (thẻ hình thứ nhất) không có hướng
public enum Direction
{
    Left,
    Right,
    Up,
    Down,
    None
}
